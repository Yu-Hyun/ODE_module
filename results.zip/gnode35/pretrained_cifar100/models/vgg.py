"""vgg in pytorch


[1] Karen Simonyan, Andrew Zisserman

    Very Deep Convolutional Networks for Large-Scale Image Recognition.
    https://arxiv.org/abs/1409.1556v6
"""
'''VGG11/13/16/19 in Pytorch.'''

import torch
import torch.nn as nn

cfg = {
    'A' : [64,     'M', 128,      'M', 256, 256,           'M', 512, 512,           'M', 512, 512,           'M'],
    'B' : [64, 64, 'M', 128, 128, 'M', 256, 256,           'M', 512, 512,           'M', 512, 512,           'M'],
    'D' : [64, 64, 'M', 128, 128, 'M', 256, 256, 256,      'M', 512, 512, 512,      'M', 512, 512, 512,      'M'],
    'E' : [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 256, 'M', 512, 512, 512, 512, 'M', 512, 512, 512, 512, 'M']
}

class VGG(nn.Module):

    def __init__(self, features, num_class=100):
        super().__init__()
        self.features = features

        self.classifier = nn.Sequential(
            nn.Linear(512, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, num_class)
        )

    def forward(self, x):
        output = self.features(x)
        output = output.view(output.size()[0], -1)
        output = self.classifier(output)

        return output
        
    def forward_1(self, x):
        x = self.features[0](x) # 3 - 64 conv2D
        x = self.features[1](x) # bn
        x = self.features[2](x) # relu
        '''
        x = self.features[3](x) # 64 - 64 conv2D
        x = self.features[4](x) # bn
        x = self.features[5](x) # relu
        
        x = self.features[6](x) # max pooling
        '''
        return x
        
    def forward_NN(self, x):
        for idx in range(3,len(self.features)):
            x = self.features[idx](x)
        x = x.view(x.size()[0], -1)
        x = self.classifier(x)
        return x
        
    def forward_L1(self, x):
        x_1 = self.forward_1(x)
        x = self.forward_NN(x_1)
        return x, x_1
        
class VGG2(nn.Module): # C = 128
    def __init__(self, features, num_class=100):
        super().__init__()
        self.features = features

        self.classifier = nn.Sequential(
            nn.Linear(512, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, num_class)
        )
    def forward(self, x):
        output = self.features(x)
        output = output.view(output.size()[0], -1)
        output = self.classifier(output)

        return output
        
    def forward_1(self, x):
        x = self.features[0](x) # 3 - 64 conv2D
        x = self.features[1](x) # bn
        x = self.features[2](x) # relu
        
        x = self.features[3](x) # 64 - 64 conv2D
        x = self.features[4](x) # bn
        x = self.features[5](x) # relu
        
        x = self.features[6](x) # max pooling
        
        x = self.features[7](x) # 3 - 64 conv2D
        x = self.features[8](x) # bn
        x = self.features[9](x) # relu
        
        x = self.features[10](x) # 64 - 64 conv2D
        x = self.features[11](x) # bn
        x = self.features[12](x) # relu
        
        x = self.features[13](x) # max pooling
        return x
        
    def forward_NN(self, x):
        for idx in range(14,len(self.features)):
            x = self.features[idx](x)
        x = x.view(x.size()[0], -1)
        x = self.classifier(x)
        return x
        
    def forward_L1(self, x):
        x_1 = self.forward_1(x)
        x = self.forward_NN(x_1)
        return x, x_1
        
class VGG3(nn.Module): # C= 256
    def __init__(self, features, num_class=100):
        super().__init__()
        self.features = features

        self.classifier = nn.Sequential(
            nn.Linear(512, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, num_class)
        )
    def forward(self, x):
        output = self.features(x)
        output = output.view(output.size()[0], -1)
        output = self.classifier(output)

        return output
        
    def forward_1(self, x):
        x = self.features[0](x) # 3 - 64 conv2D
        x = self.features[1](x) # bn
        x = self.features[2](x) # relu
        
        x = self.features[3](x) # 64 - 64 conv2D
        x = self.features[4](x) # bn
        x = self.features[5](x) # relu
        
        x = self.features[6](x) # max pooling
        
        x = self.features[7](x) # 64-128 conv2D
        x = self.features[8](x) # bn
        x = self.features[9](x) # relu
        
        x = self.features[10](x) # 128-128 conv2D
        x = self.features[11](x) # bn
        x = self.features[12](x) # relu
        
        x = self.features[13](x) # max pooling
        
        x = self.features[14](x) # 128-256conv2D
        x = self.features[15](x) # bn
        x = self.features[16](x) # relu
        
        x = self.features[17](x) # 256-256conv2D
        x = self.features[18](x) # bn
        x = self.features[19](x) # relu
        
        x = self.features[20](x) # 256-256conv2D
        x = self.features[21](x) # bn
        x = self.features[22](x) # relu
        
        x = self.features[23](x) # Max pooling
        return x
        
    def forward_NN(self, x):
        for idx in range(24,len(self.features)):
            x = self.features[idx](x)
        x = x.view(x.size()[0], -1)
        x = self.classifier(x)
        return x
        
    def forward_L1(self, x):
        x_1 = self.forward_1(x)
        x = self.forward_NN(x_1)
        return x, x_1
        
class VGG4(nn.Module): # C = 512
    def __init__(self, features, num_class=100):
        super().__init__()
        self.features = features

        self.classifier = nn.Sequential(
            nn.Linear(512, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, num_class)
        )
    def forward(self, x):
        output = self.features(x)
        output = output.view(output.size()[0], -1)
        output = self.classifier(output)

        return output
        
    def forward_1(self, x):
        x = self.features[0](x) # 3 - 64 conv2D
        x = self.features[1](x) # bn
        x = self.features[2](x) # relu
        
        x = self.features[3](x) # 64 - 64 conv2D
        x = self.features[4](x) # bn
        x = self.features[5](x) # relu
        
        x = self.features[6](x) # max pooling
        
        x = self.features[7](x) # 64-128 conv2D
        x = self.features[8](x) # bn
        x = self.features[9](x) # relu
        
        x = self.features[10](x) # 128-128 conv2D
        x = self.features[11](x) # bn
        x = self.features[12](x) # relu
        
        x = self.features[13](x) # max pooling
        
        x = self.features[14](x) # 128-256conv2D
        x = self.features[15](x) # bn
        x = self.features[16](x) # relu
        
        x = self.features[17](x) # 256-256conv2D
        x = self.features[18](x) # bn
        x = self.features[19](x) # relu
        
        x = self.features[20](x) # 256-256conv2D
        x = self.features[21](x) # bn
        x = self.features[22](x) # relu
        
        x = self.features[23](x) # Max pooling
        
        x = self.features[24](x) # 128-256conv2D
        x = self.features[25](x) # bn
        x = self.features[26](x) # relu
        
        x = self.features[27](x) # 256-256conv2D
        x = self.features[28](x) # bn
        x = self.features[29](x) # relu
        
        x = self.features[30](x) # 256-256conv2D
        x = self.features[31](x) # bn
        x = self.features[32](x) # relu
        
        x = self.features[33](x) # Max pooling
        return x
        
    def forward_NN(self, x):
        for idx in range(34,len(self.features)):
            x = self.features[idx](x)
        x = x.view(x.size()[0], -1)
        x = self.classifier(x)
        return x
        
    def forward_L1(self, x):
        x_1 = self.forward_1(x)
        x = self.forward_NN(x_1)
        return x, x_1


def make_layers(cfg, batch_norm=False):
    layers = []

    input_channel = 3
    for l in cfg:
        if l == 'M':
            layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
            continue

        layers += [nn.Conv2d(input_channel, l, kernel_size=3, padding=1)]

        if batch_norm:
            layers += [nn.BatchNorm2d(l)]

        layers += [nn.ReLU(inplace=True)]
        input_channel = l

    return nn.Sequential(*layers)
    


def vgg11_bn():
    return VGG(make_layers(cfg['A'], batch_norm=True))

def vgg13_bn():
    return VGG(make_layers(cfg['B'], batch_norm=True))

def vgg16_bn():
    return VGG(make_layers(cfg['D'], batch_norm=True))
    
def vgg16_bn_2():
    return VGG2(make_layers(cfg['D'], batch_norm=True))
    
def vgg16_bn_3():
    return VGG3(make_layers(cfg['D'], batch_norm=True))
    
def vgg16_bn_4():
    return VGG4(make_layers(cfg['D'], batch_norm=True))

def vgg19_bn():
    return VGG(make_layers(cfg['E'], batch_norm=True))


